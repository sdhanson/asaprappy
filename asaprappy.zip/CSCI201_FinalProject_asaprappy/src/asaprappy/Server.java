package asaprappy;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.util.Random;
import java.util.Vector;


public class Server {
	String[] screenNames = {"Whoopy Panda", 
			"Dimple Doll", 
			"Crazy KupKakes", 
			"Squiggly Munchkin", 
			"Sizzlin Teapot", 
			"Gold Queenie", 
			"Pinkie Cutie", 
			"Dodo Chip", 
			"Gummielicious Bling", 
			"Brown Hunnie", 
			"Fizzy Brown", 
			"Scribbly Lightning", 
			"Panda Heart", 
			"Sweet Whimsy", 
			"Ninja Rock", 
			"Secret Fruity", 
			"Blossom Cotton", 
			"Ice Huggy", 
			"Forever Bubblegum", 
			"Delicious Raspberry", 
			"Fruity Charm", 
			"Diva Tulips", 
			"Super Giggles", 
			"Butterscotch Seven", 
			"Sleepy Tinker", 
			"Fudgy Turkey", 
			"Mayflower Madame", 
			"Mystical Dimples", 
			"Kute Poopie", 
			"Twittie Sparkles", 
			"Tiger Swirlie", 
			"Triple Adorable", 
			"Bedazzzled Blue", 
			"Piggy Twinkling", 
			"Glitzy Go", 
			"Cream Smiley", 
			"Cupcake Hugs", 
			"Fairytale Daisy", 
			"Tigger Fresh", 
			"Pickle Pinkest", 
			"Dazzlin Princess", 
			"Happy Muah", 
			"Shy Snicker", 
			"Furry Dimples", 
			"Live Chic", 
			"Happy Wow", 
			"Lil Cutie", 
			"Wabbit Cherry", 
			"Prinky Doodsie", 
			"Teddie Doc", 
			"Secret Snowy", 
			"Cupid Hot", 
			"Frisbee Doodsie", 
			"Bunny Passion", 
			"Chocolatey Smile", 
			"Dimple Caramel", 
			"Petty Picnic", 
			"One Chewy", 
			"Prinky Shortiepants", 
			"Sugary Heaven", 
			"Tickle Star", 
			"Pretty Pumpkin", 
			"Warm Sunflower", 
			"Golden Tickle", 
			"Daisy Ladybird", 
			"Forever Choco", 
			"Blushy Pinkest", 
			"Circus Halo", 
			"Jelly Snowballs", 
			"Pickle Raindrops", 
			"Flying Cupid", 
			"Neon Girl", 
			"Gold Cherry", 
			"Mmm Tank", 
			"Squishy Bionic", 
			"Doozles Fairy", 
			"Honey Sparky", 
			"Beach Bionic", 
			"Songbird Garden", 
			"Peanut Mockingbird", 
			"Waffle Glitter", 
			"Icing Crystal", 
			"Rainbow Sweety", 
			"Waffle Friends", 
			"Dandelion Monster", 
			"Boogie Lollipop", 
			"Twin Dazzlin", 
			"Sugar Genius", 
			"Shiny Soo", 
			"Golden Tee", 
			"Snuggle Kitty", 
			"Gold Jewel", 
			"Dazzlin Snuggle", 
			"Genie Dolphin", 
			"Fluffy Marshmallow", 
			"Fuzzie Cherry", 
			"Magic Pizza", 
			"Delicious Cinnamon", 
			"Furry Fairytale", 
			"Chicky Kute", 
			"Spring Lucky", 
			"Star Cherrie", 
			"Miss Turkey", 
			"Autumn Spring", 
			"Secret Giggle", 
			"Raspberry Fortune", 
			"Twinkling Muah", 
			"Sweetie Wow", 
			"Trixie Grizzly", 
			"Squishy Doll", 
			"Jelly Cuddles", 
			"Boogie Neon", 
			"Hugsie Princess", 
			"Tweetie Peachie", 
			"Twilight Queenbee", 
			"Jelly Bubbly", 
			"Sugarplum Chum", 
			"Sweet Hey", 
			"Hunnie Froggie", 
			"Breezy Boo", 
			"Raspberry Trixie", 
			"Huggable Babe", 
			"Jazzie Flip", 
			"Mega Mayhem", 
			"Princess Munchkin", 
			"Me Mini", 
			"Cream Twinkie", 
			"Tiny Bubble", 
			"Cookee Chicky", 
			"Banana Fizzy", 
			"Queen Doodsie", 
			"Flip Hug", 
			"Grinning Prinky", 
			"Icy Peppermint", 
			"Blueberrie Ham", 
			"Vanilla Angelic", 
			"Girlie Chum", 
			"Cutie Bun", 
			"Fudgy Karot", 
			"Snowflakes Mega", 
			"Fancy Hunny", 
			"Polka Pinky", 
			"Dazzzled Sweetie", 
			"Scooby Bumble", 
			"Candycane Missy", 
			"Triple Girly", 
			"Tiger Kitty", 
			"Qwerty Bells", 
			"Chicken Cuddles", 
			"Bubbling Clumzie", 
			"Chatterbug Megastar", 
			"Squeezie Teapot", 
			"Dizzy Smilie", 
			"Glitzy Piggy", 
			"Magic Peach", 
			"Orange Cookie", 
			"Ultimate Angelstar", 
			"Huggable Pickle", 
			"Melon Passion", 
			"Frog Cherry", 
			"Soft Mambo", 
			"Blondie Button", 
			"Cosmopolitan Twinkles", 
			"Sweet Pearl", 
			"Sugarplum Dimple", 
			"Fizzy Madame", 
			"Cream Candycane", 
			"Chocolatey Neon", 
			"Jingle Dollie", 
			"Tinker Angel", 
			"Silhouette Hunnie", 
			"Goofy Carot", 
			"Funny Doc", 
			"Precious Pinkest", 
			"Sweetie Sweety", 
			"Chickie Magic", 
			"Miss Candied", 
			"Cryztal Blondie", 
			"Candy Salt", 
			"Diamond Guardian", 
			"Frog Light", 
			"Lolly Bling", 
			"Grizzly Turkey", 
			"Kookie Poochie", 
			"Chewy Muffin", 
			"Babycake Ballerina", 
			"Dixie Doodles", 
			"Twinkling Melody"};
	//188 names
	
	private Vector<ServerThread> serverThreads;
	
	public Server(int port) {
		try {
			System.out.println("Binding to port " + port);
			ServerSocket ss = new ServerSocket(port);
			System.out.println("Bound to port " + port);
			serverThreads = new Vector<ServerThread>();
			while(true) {
				Socket s = ss.accept(); // blocking
				System.out.println("Connection from: " + s.getInetAddress());
				ServerThread st = new ServerThread(s, this);
				serverThreads.add(st);
			}
		} catch (IOException ioe) {
			System.out.println("ioe in Server constructor: " + ioe.getMessage());
		}
	}
	
	public Data logUserIn(Data dob) { //might want to make this synchronized
		JDBCDriver.connect();
		String screenName = "";
		try {
			JDBCDriver.ps = JDBCDriver.conn.prepareStatement("SELECT screenName FROM Users WHERE email=?");
			JDBCDriver.ps.setString(1, dob.getEmail());
			JDBCDriver.rs = JDBCDriver.ps.executeQuery();
			if(JDBCDriver.rs.next()) {
				//user exists
				//pull screen name, set active to true
				screenName = JDBCDriver.rs.getString("screenName");
				JDBCDriver.ps = JDBCDriver.conn.prepareStatement("UPDATE Users SET active=true WHERE email=?");
				JDBCDriver.ps.setString(1, dob.getEmail());
				JDBCDriver.ps.execute();
			} else {
				//user doesn't exist
				Random rand = new Random();
				int index = rand.nextInt(188); //generate a number between 0 and 187
				screenName = screenNames[index];
				System.out.println("Screen name: " + screenName); //DEBUG
				
				JDBCDriver.ps = JDBCDriver.conn.prepareStatement("INSERT INTO Users (email, fullName, screenName, song, active) VALUES (?, ?, ?, '', true);");
				JDBCDriver.ps.setString(1, dob.getEmail());
				JDBCDriver.ps.setString(2, dob.getFullname());
				JDBCDriver.ps.setString(3, screenName);
				JDBCDriver.ps.execute();
			}
		} catch(SQLException sqle) {
			System.out.println("SQLException thrown in user login: " + sqle.getMessage());
		} finally {
			try {
				if (JDBCDriver.rs != null) {
					JDBCDriver.rs.close();
				}
				if (JDBCDriver.ps != null) {
					JDBCDriver.ps.close();
				}
				if (JDBCDriver.conn != null) {
					JDBCDriver.conn.close();
				}
			} catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		//send screen name back to front end
		dob.setScreename(screenName);
		return dob;
	}
	
	public Data logUserOut(Data dataObj) {
		JDBCDriver.connect();
		try {
			JDBCDriver.ps = JDBCDriver.conn.prepareStatement("UPDATE Users SET active=false WHERE email=?");
			JDBCDriver.ps.setString(1, dataObj.getEmail());
			JDBCDriver.ps.execute();
		} catch(SQLException sqle) {
			System.out.println("SQLException thrown in user logout: " + sqle.getMessage());
		} finally {
			try {
				if (JDBCDriver.rs != null) {
					JDBCDriver.rs.close();
				}
				if (JDBCDriver.ps != null) {
					JDBCDriver.ps.close();
				}
				if (JDBCDriver.conn != null) {
					JDBCDriver.conn.close();
				}
			} catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		return dataObj;
	}
	
	public void saveSong(Data datObj) {
		JDBCDriver.connect();
		try {
			JDBCDriver.ps = JDBCDriver.conn.prepareStatement("UPDATE Users SET song=? WHERE email=?");
			JDBCDriver.ps.setString(1, datObj.getSong());
			JDBCDriver.ps.setString(2, datObj.getEmail());
			JDBCDriver.ps.execute();
		} catch(SQLException sqle) {
			System.out.println("SQLException thrown in song save: " + sqle.getMessage());
		} finally {
			try {
				if (JDBCDriver.rs != null) {
					JDBCDriver.rs.close();
				}
				if (JDBCDriver.ps != null) {
					JDBCDriver.ps.close();
				}
				if (JDBCDriver.conn != null) {
					JDBCDriver.conn.close();
				}
			} catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
	}
	
	public void broadcast(Data dataObj) {
		if (dataObj != null) {
			for (ServerThread st : serverThreads) {
				st.sendData(dataObj);
			}
		}
	}
	
	public static void main(String[] args) {
		new Server(6789);
	}

}
