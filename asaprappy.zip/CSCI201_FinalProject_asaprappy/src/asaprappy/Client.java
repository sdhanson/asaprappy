package asaprappy;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javafx.util.Pair;

/**
 * Servlet implementation class Client
 */
@WebServlet("/Client")
public class Client extends HttpServlet implements Runnable {
	private static final long serialVersionUID = 1L;
    
	private static String hostname = "localhost";
	private static int port = 6789;
	
	//for serialization
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	
	Data dataObj;
	
	Client cl;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Client() {
        super();
		//use socket for client, serversocket on server
		//socket takes in hostname and port to connect to ther server
		Socket s = null;
		try {
			System.out.println("Trying to connect to " + hostname + ":" + port);
			s = new Socket(hostname, port);
			System.out.println("Connected!");
			
			//Serializable objects stuff
			oos = new ObjectOutputStream(s.getOutputStream());
			ois = new ObjectInputStream(s.getInputStream());
			
			this.run(); //again, only if I get the br and pw without exception do I start the thread
		} catch (IOException ioe) {
			System.out.println("ioe ChatClient: " + ioe.getMessage());
		} finally {
			try {
				if (ois != null) {
					ois.close();
				}
				if (oos != null) {
					oos.close();
				}
				if (s != null) {
					s.close();
				}
			} catch (IOException ioe) {
				System.out.println("ioe closing socket: " + ioe.getMessage());
			}
		}
    }

    //Creates HTML string of HTML users
    public String createHTML(Vector<Pair<String, Boolean>> activeUsers) {
    	String sampleHTML = "<div class=\"row d-flex justify-content-center\">\n" + 
    			"		<!-- image of most used rapper -->\n" + 
    			"		<div class='w-100 d-flex justify-content-center'>\n" + 
    			"				<img src=\"src/pitbull.png\" id=\"mostusedrapper\"> \n" + 
    			"		</div>\n" + 
    			"		\n" + 
    			"		<!-- randomly generated screen name -->\n" + 
    			"		<div class=\"justify-content-center\" id=\"screen-name\">\n" + 
    			dataObj.getScreename() + 
    			"		</div>\n" + 
    			"	</div> ";
    	
    	sampleHTML += "	<div class=\"row justify-content-center\" id=\"friends\">	\n" + 
    			"		<!-- active users text -->		\n" + 
    			" 		<img src=\"src/activeusers.png\" id=\"activeuserstext\">\n" + 
    			"		<div class=\"side w-100\" id=\"activetable\">\n" +
    			"<ul class=\"w-100\">\n";
    	
    	for(int i = 0;i < activeUsers.size(); i++) {
    		String status;
    		if(!activeUsers.get(i).getKey().equals(dataObj.getScreename())) {
    			if(activeUsers.get(i).getValue() == true) {
        			status = "<img src=\"src/online.png\">\n";
        		} else {
        			status = "<img src=\"src/offline2.png\">\n";
        		}
        		sampleHTML += "				<li class=\"user w-100\">\n" + 
        				status + 
        				"					<span class=\"ml-1 username\"> " + activeUsers.get(i).getKey() + " </span>\n" + 
        				"				</li>";
    		}
    		
    	}
    	sampleHTML += "</ul>\n" + 
    			"		</div>";
    	return sampleHTML;
    }
    
    private Vector<Pair<String, Boolean>> getActives() {
    	return dataObj.getActives();
    }
    
	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String status = request.getParameter("Status");
		
		//send the stuff above to server
		if (cl == null) {
			cl = new Client();
		}
		
		//request the below based on status
//		String fullname = request.getParameter("FullName");
//		String email = request.getParameter("Email");
//		String song = request.getParameter("Song");
		
		if (status.equals("Login")) {
			String fullname = request.getParameter("FullName");
			String email = request.getParameter("Email");
			
			dataObj.setFullname(fullname);
			dataObj.setEmail(email);
			dataObj.setStatus("Login");
			dataObj.setActive(true);
			
			oos.writeObject(dataObj);
			oos.flush();
		}
		else if (status.equals("Song")) {
			String song = request.getParameter("Song");
			
			dataObj.setSong(song);
			dataObj.setStatus("Song");
			oos.writeObject(dataObj);
			oos.flush();
		}
		else if (status.equals("Logout")) {
			//log out
			dataObj.setActive(false);
			dataObj.setStatus("Logout");
			oos.writeObject(dataObj);
			oos.flush();
		}
		
		if (status.equals("UpdateSidebar")) {
			Vector<Pair<String, Boolean>> activeUsers = getActives();
			createHTML(activeUsers);
		}
	}

	@Override
	public void run() {
		try {
			//this gets Data objects from the server
			while (true) {
				Data d = (Data)ois.readObject();
				//do something with the data object
				dataObj = d;
			}
		} catch (IOException ioe) {
			System.out.println("ioe in run: " + ioe.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.println("cnfe in run: " + cnfe.getMessage());
		}
	}
}
