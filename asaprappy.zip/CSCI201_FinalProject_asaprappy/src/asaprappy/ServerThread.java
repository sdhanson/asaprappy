package asaprappy;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ServerThread extends Thread {
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	
	Server server;
	
	ServerThread(Socket s, Server se) {		
		try {
			this.server = se;
			oos = new ObjectOutputStream(s.getOutputStream());
			ois = new ObjectInputStream(s.getInputStream());
			this.start();
		}
		catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
		
	}
	
	public void sendData(Data dataObj) {
		try {
			oos.writeObject(dataObj);
			oos.flush();
		}
		catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
	}
	
	public void run() {
		//this reads Data from client
		try {
			while (true) {
				Data dataObj = (Data)ois.readObject(); //blocking
				
				String status = dataObj.getStatus();
				
				if (status.equals("Login")) {
					server.broadcast(server.logUserIn(dataObj));
				}
				else if (status.equals("Logout")) {
					server.broadcast(server.logUserOut(dataObj));
				}
				else if (status.equals("Song")) {
					server.saveSong(dataObj);
				}
			}
		}
		 catch (IOException ioe) {
			System.out.println("ioe in ServerThread.run(): " + ioe.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.println("cnfe in ServerThread.run(): " + cnfe.getMessage());
		}
	}
}
